import basic_import

def test_basic_recurcive_import():
    assert basic_import.test_basic_import() == 6


if __name__ == "__main__":
    test_basic_recurcive_import()
