import sys
import local_package

print(local_package.pi.pi)